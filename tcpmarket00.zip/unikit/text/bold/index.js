import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const PBold = ({text}) => {
    return (
      <p className="bold">{text}</p>
    );
}
export default PBold;
