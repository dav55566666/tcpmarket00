import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const PBigbold = ({text}) => {
    return (
      <p className="bigbold">{text}</p>
    );
}
export default PBigbold;
