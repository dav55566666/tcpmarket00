import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const P = ({text}) => {
    return (
      <p className="normal">{text}</p>
    );
}
export default P;
