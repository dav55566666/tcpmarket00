import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const PBig = ({text}) => {
    return (
      <p className="big">{text}</p>
    );
}
export default PBig;
