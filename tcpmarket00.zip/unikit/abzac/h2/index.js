import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const H2 = ({abzac}) => {
    return (
      <h2>{abzac}</h2>
    );
}
export default H2;
