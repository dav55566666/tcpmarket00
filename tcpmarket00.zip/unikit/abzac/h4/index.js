import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const H4 = ({abzac}) => {
    return (
      <h4>{abzac}</h4>
    );
}
export default H4;
