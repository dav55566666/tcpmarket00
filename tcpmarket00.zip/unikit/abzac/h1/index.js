import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const H1 = ({abzac}) => {
    return (
      <h1>{abzac}</h1>
    );
}
export default H1;
