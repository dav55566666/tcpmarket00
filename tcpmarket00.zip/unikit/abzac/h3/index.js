import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const H3 = ({abzac}) => {
    return (
      <h3>{abzac}</h3>
    );
}
export default H3;
