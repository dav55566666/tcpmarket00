import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const H5 = ({abzac}) => {
    return (
      <h5>{abzac}</h5>
    );
}
export default H5;
