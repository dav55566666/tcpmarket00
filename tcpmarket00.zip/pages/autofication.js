import DueAutofication from '../Components/Main/Login/DueAutofication/dueAutofication';

export default function Home() {
  return <DueAutofication />;
}
