import Succes from '../Components/Main/Login/Succes/succes';

export default function Home() {
  return <Succes />;
}
