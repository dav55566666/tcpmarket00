import {Fragment} from 'react';
import Aoutorize from '../Components/Main/Login/Aoutorization/aoutorize';

export default function Home() {
  return <Aoutorize />;
}
