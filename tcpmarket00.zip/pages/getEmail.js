import GetEmail from '../Components/Main/Login/GetEmail/getEmail';

export default function Home() {
  return <GetEmail />;
}
