import Registration from '../Components/Main/Login/Registration/registration';

export default function Home() {
  return <Registration />;
}
