import GetPassword from '../Components/Main/Login/GetPassword/getPassword';

export default function Home() {
  return <GetPassword />;
}
