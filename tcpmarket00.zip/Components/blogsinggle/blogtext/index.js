import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const Blogsingletext = ({blogtext}) => {
    return (
      <p>{blogtext}</p>
    );
}
export default Blogsingletext;
