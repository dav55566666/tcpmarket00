import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const Li = ({litext}) => {
    return (
      <li>{litext}</li>
    );
}
export default Li;
