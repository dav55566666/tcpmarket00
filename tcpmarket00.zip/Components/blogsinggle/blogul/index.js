import PropTypes from 'prop-types';
import React, { useRef, useState } from "react";

const Ul = ({children}) => {
    return (
      <ul>{children}</ul>
    );
}
export default Ul;
